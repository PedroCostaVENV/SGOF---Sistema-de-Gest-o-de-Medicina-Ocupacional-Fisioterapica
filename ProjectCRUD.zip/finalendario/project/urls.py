"""project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include
from app.views import home, cadastro, login, cadastrobd, fisioterapia, createfisio, teste, viewusuario, editar, updateusuario, deleteusuario, telclinica, telespecialidades, telmedicos
from usuarios.views import loginmed, cadastromed, telmedico, view, edit, update, delete, createclinica, clinicaform, especialidadesform, createespecialidades, medicoform, createmedico, dataform, createdata

urlpatterns = [
    path('admin/', admin.site.urls),
    path('cadastromed/', cadastromed, name='cadastromed'),
    path('loginmed/', loginmed, name='loginmed'),
    path('telmedico/', telmedico, name='telmedico'),
    path('', home, name='home'),
    path('cadastro/', cadastro, name='cadastro'),
    path('cadastrobd/', cadastrobd, name='cadastrobd'),
    path('login/', login, name='login'),
    path('teste/', teste, name='teste'),
    path('fisioterapia/', fisioterapia, name='fisioterapia'),
    path('createfisio/', createfisio, name='createfisio'),
    path('view/<int:pk>/', view, name='view'),
    path('viewusuario/<int:cpf>/', viewusuario, name='viewusuario'),
    path('edit/<int:pk>/', edit, name='edit'),
    path('editar/<int:cpf>/', editar, name='editar'),
    path('update/<int:pk>/', update, name='update'),
    path('updateusuario/<int:pk>/', updateusuario, name='updateusuario'),
    path('delete/<int:pk>/', delete, name='delete'),
    path('deleteusuario/<int:cpf>/', deleteusuario, name='deleteusuario'),
    path('createclinica/', createclinica, name='createclinica'),
    path('clinicaform/', clinicaform, name='clinicaform'),
    path('especialidadesform/', especialidadesform, name='especialidadesform'),
    path('telclinica/', telclinica, name='telclinica'),
    path('createespecialidades/', createespecialidades, name='createespecialidades'),
    path('telespecialidades/', telespecialidades, name='telespecialidades'),
    path('medicoform/', medicoform, name='medicoform'),
    path('createmedico/', createmedico, name='createmedico'),
    path('telmedicos/', telmedicos, name='telmedicos'),
    path('dataform/', dataform, name='dataform'),
    path('createdata/', createdata, name='createdata'),
]

