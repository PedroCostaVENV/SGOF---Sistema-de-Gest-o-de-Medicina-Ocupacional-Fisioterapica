from django.forms import ModelForm
from app.models import CadastroTeste, Cliente
from django import forms

from datetime import datetime

class CadastroForm(ModelForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Digite um usuário...'}))
    senha = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Senha...'}))
    email = forms.EmailField(label='email', widget=forms.TextInput(attrs={'placeholder': 'E-mail...'}))
    class Meta:
        model = CadastroTeste
        fields = ['username','email', 'senha']


# Criar uma formatação parecida com essa %d-%m às %Hh%i'
class ClienteForm(ModelForm):
    nome = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Digite seu nome...'}))
    data_nasc = forms.DateField(
        label=('Data de Nascimento:'),
        input_formats=["%d/%m/%Y",],
        widget=forms.DateInput(format='%d/%m/%Y')
    )
    email = forms.EmailField(label='email', widget=forms.TextInput(attrs={'placeholder': 'E-mail...'}))
    aqtad = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'A quanto tempo apresenta dor?'}))
    sdi = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Sua dor irradia?'}))
    qedsi = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Quando essa dor se inicia?'}))
    fam = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Faz acompanhamento médico?'}))
    palncc = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Possui alguma lesão na coluna cervical?'}))
    especifique = forms.Textarea()
    class Meta:
        model = Cliente
        fields = ['nome', 'data_nasc', 'cpf', 'telefone', 'email', 'cidade', 'aqtad', 'tddc', 'sdi', 'qedsi', 'fam', 'tmc', 'adpcm', 'umc', 'pmtccb', 'palncc', 'especifique', 'utpd']

