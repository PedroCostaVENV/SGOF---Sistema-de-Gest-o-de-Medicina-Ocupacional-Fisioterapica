from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic import CreateView
from app.forms import CadastroForm, ClienteForm
from django.contrib.auth.models import User
from app.models import CadastroTeste, Cliente
from usuarios.models import Clinica, Especialidades, AgendamentoTeste, Medicos
from django.urls import reverse_lazy

# Create your views here.

def home(request):
    return render(request, 'index.html')

def cadastro(request):
    data = {}
    data['form'] = CadastroForm()
    email = request.GET.get('email')
    if email:
        data['db'] = CadastroTeste.objects.filter(email__icontains=email)
        return HttpResponse("Já existe um usuário com esse e-mail")
    else:
        data['db'] = CadastroTeste.objects.all()
        return render(request, 'cadastro.html', data)

def cadastrobd(request):
    form = CadastroForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('login')
    else:
        return HttpResponse("Digite o e-mail da forma correta com o @ e .com sendo obrigatorio")

def login(request):
    data = {}
    senha = request.GET.get('senha')
    login = request.GET.get('login')
    if senha and login:
        try:
            data['db'] = CadastroTeste.objects.get(senha=senha)
            data['db'] = CadastroTeste.objects.get(username=login)
        except Exception as erro:
            return HttpResponse("Usuário ou senha inválida")
        return redirect('fisioterapia')
    else:
        data['db'] = CadastroTeste.objects.all()
        #return HttpResponse("Usuário ou senha inválidos")
    return render(request, "login.html")

def fisioterapia(request):
    data = {}
    data['form'] = ClienteForm()
    return render(request, 'fisioterapia.html', data)

def createfisio(request):
    form = ClienteForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('teste')

def teste(request):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Cliente.objects.get(cpf__icontains=search)
        return render(request, "viewusuario.html", data)
    else:
        data['db'] = Cliente.objects.all()
        return render(request, "teste.html", data)

def viewusuario(request, cpf):
    data = {}
    data['db'] = Cliente.objects.get(cpf=cpf)
    return render(request, 'usuario.html', data)

def editar(request, cpf):
    data = {}
    data['db'] = Cliente.objects.get(cpf=cpf)
    data['form'] = ClienteForm(instance=data['db'])
    return render(request, 'fisioterapia.html', data)

def updateusuario(request, cpf):
    data = {}
    data['db'] =  Cliente.objects.get(cpf=cpf)
    form = ClienteForm(request.POST or None, instance=data['db'])
    if form.is_valid():
        form.save()
        return redirect('home')

def deleteusuario(request, cpf):
    db = Cliente.objects.get(cpf=cpf)
    db.delete()
    return redirect('home')

def telclinica(request):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Clinica.objects.filter(nome__icontains=search)
    else:
        data['db'] = Clinica.objects.all()
    return render(request, 'telclinica.html', data)

def telespecialidades(request):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Medicos.objects.filter(especialidade__icontains=search)
        return render(request, "telmedicos.html", data)
    else:
        data['db'] = Especialidades.objects.all()
    return render(request, 'telespecialidades.html', data)

def telmedicos(request, especialidade):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Medicos.objects.filter(especialidades__icontains=search)
        return render(request, "telmedicos.html", data)
    else:
        data['db'] = Medicos.objects.all()
    return render(request, 'telmedicos.html', data)

