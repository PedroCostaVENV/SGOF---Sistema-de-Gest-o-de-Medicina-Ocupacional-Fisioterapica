from django.forms import ModelForm
from app.models import CadastroTeste, Cliente
from .models import AgendamentoTeste, Especialidades, Medicos, Clinica
from django import forms

class ClinicaForm(ModelForm):
    class Meta:
        model = Clinica
        fields = ['nome', 'rua', 'numero', 'cidade', 'cep']

class EspecialidadesForm(ModelForm):
    class Meta:
        model = Especialidades
        fields = ['especialidades']

class MedicosForm(ModelForm):
    class Meta:
        model = Medicos
        fields = ['nome','crm', 'idade', 'especialidade']

class AgendamentoForm(ModelForm):
    data = forms.DateField(
        label=('Data de Nascimento:'),
        input_formats=["%d/%m/%Y",],
        widget=forms.DateInput(format='%d/%m/%Y')
    )
    class Meta:
        model = AgendamentoTeste
        fields = ['data', 'hora']