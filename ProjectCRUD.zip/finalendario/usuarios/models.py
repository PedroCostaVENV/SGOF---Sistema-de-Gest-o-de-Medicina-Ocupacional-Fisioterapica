from django.db import models
from datetime import datetime
# Create your models here.

class Clinica(models.Model):
    nome = models.CharField(max_length=100)
    rua = models.CharField(max_length=100)
    numero = models.IntegerField()
    cidade = models.CharField(max_length=100)
    cep = models.IntegerField()

class AgendamentoTeste(models.Model):
    data = models.DateField()
    hora = models.CharField(max_length=5)

class Especialidades(models.Model):
    especialidades = models.CharField(max_length=100)

class Medicos(models.Model):
    nome = models.CharField(max_length=100)
    crm = models.IntegerField()
    idade = models.IntegerField()
    especialidade = models.CharField(max_length=100)

