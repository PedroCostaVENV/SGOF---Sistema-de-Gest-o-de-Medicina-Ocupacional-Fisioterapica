from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from app.models import CadastroTeste, Cliente
from app.forms import ClienteForm, CadastroForm, Cliente, CadastroTeste
from .forms import ClinicaForm, EspecialidadesForm, MedicosForm, AgendamentoForm
from django.core.paginator import Paginator

# Create your views here.

def cadastromed(request):
    if request.method == "GET":
        return render(request, 'cadastromed.html')
    else:
        username = request.POST.get('username')
        email = request.POST.get('email')
        senha = request.POST.get('senha')

        user = User.objects.filter(username=username).first()

        if user:
            return HttpResponse('Já existe um usuário com esse username')

        user = User.objects.create_user(username=username, email=email, password=senha)
        user.save()

        return HttpResponse("Usuário cadastrado com sucesso")

def loginmed(request):
    if request.method == "GET":
        return render(request, 'loginmed.html')
    else:
        username = request.POST.get('username')
        senha = request.POST.get('senha')

        user = authenticate(username=username, password=senha)
        if user:
            return redirect("/telmedico/")
        else:
            return HttpResponse("Usuário ou senha inválida")

def telmedico(request):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Cliente.objects.filter(nome__icontains=search)
    else:
        data['db'] = Cliente.objects.all()
    return render(request, 'telmedico.html', data)

def view(request, pk):
    data = {}
    data['db'] = Cliente.objects.get(pk=pk)
    return render(request, 'view.html', data)

def edit(request, pk):
    data = {}
    data['db'] = Cliente.objects.get(pk=pk)
    data['form'] = ClienteForm(instance=data['db'])
    return render(request, 'fisioterapia.html', data)

def update(request, pk):
    data = {}
    data['db'] =  Cliente.objects.get(pk=pk)
    form = ClienteForm(request.POST or None, instance=data['db'])
    if form.is_valid():
        form.save()
        return redirect('home')

def delete(request, pk):
    db = Cliente.objects.get(pk=pk)
    db.delete()
    return redirect('telmedico')

def clinicaform(request):
    data = {}
    data['form'] = ClinicaForm()
    return render(request, 'clinicaform.html', data)

def createclinica(request):
    form = ClinicaForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')

def especialidadesform(request):
    data = {}
    data['form'] = EspecialidadesForm()
    return render(request, 'especialidadesform.html', data)

def createespecialidades(request):
    form = EspecialidadesForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')

def medicoform(request):
    data = {}
    data['form'] = MedicosForm()
    return render(request, 'medicoform.html', data)

def createmedico(request):
    form = MedicosForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')

def dataform(request):
    data = {}
    data['form'] = AgendamentoForm()
    return render(request, 'dataform.html', data)

def createdata(request):
    form = AgendamentoForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')

