from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic import CreateView
from app.forms import CadastroForm, ClienteForm
from django.contrib.auth.models import User
from app.models import Cadastro, Cliente
from usuarios.models import Clinica, Especialidades, AgendamentoTeste, Medicos, Confirmar
from usuarios.forms import ConfirmarForm, AgendamentoForm, MedicosForm
from django.urls import reverse_lazy
from twilio.rest import Client
# Create your views here.

account_sid = "AC2217611c3fad83591308313c0a14aded"
auth_token  = "77efc9d343998064fa5636adabf9194d"
client = Client(account_sid, auth_token)

def home(request):
    return render(request, 'index.html')

def cadastro(request):
    data = {}
    data['form'] = CadastroForm()
    email = request.GET.get('email')
    if email:
        data['db'] = Cadastro.objects.filter(email__icontains=email)
        return HttpResponse("Já existe um usuário com esse e-mail")
    else:
        data['db'] = Cadastro.objects.all()
        return render(request, 'cadastro.html', data)

def cadastrobd(request):
    form = CadastroForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('login')
    else:
        return HttpResponse("Digite o e-mail da forma correta com o @ e .com sendo obrigatorio")

def login(request):
    data = {}
    senha = request.GET.get('senha')
    login = request.GET.get('login')
    if senha and login:
        try:
            data['db'] = Cadastro.objects.get(senha=senha)
            data['db'] = Cadastro.objects.get(username=login)
        except Exception as erro:
            return redirect("telerro")
        return redirect('fisioterapia')
    else:
        data['db'] = Cadastro.objects.all()
        #return HttpResponse("Usuário ou senha inválidos")
    return render(request, "login.html")

def fisioterapia(request):
    data = {}
    data['form'] = ClienteForm()
    return render(request, 'fisioterapia.html', data)

def createfisio(request):
    form = ClienteForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('teste')

def teste(request):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Cliente.objects.get(cpf__icontains=search)
        return render(request, "viewusuario.html", data)
    else:
        data['db'] = Cliente.objects.all()
        return render(request, "teste.html", data)

def viewusuario(request, cpf):
    data = {}
    data['db'] = Cliente.objects.get(cpf=cpf)
    return render(request, 'usuario.html', data)

def editar(request, cpf):
    data = {}
    data['db'] = Cliente.objects.get(cpf=cpf)
    data['form'] = ClienteForm(instance=data['db'])
    return render(request, 'fisioterapia.html', data)

def updateusuario(request, cpf):
    data = {}
    data['db'] =  Cliente.objects.get(cpf=cpf)
    form = ClienteForm(request.POST or None, instance=data['db'])
    if form.is_valid():
        form.save()
        return redirect('viewusuario')

def deleteusuario(request, cpf):
    db = Cliente.objects.get(cpf=cpf)
    db.delete()
    return redirect('home')

def telclinica(request):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Clinica.objects.filter(nome__icontains=search)
    else:
        data['db'] = Clinica.objects.all()
    return render(request, 'telclinica.html', data)

def telespecialidades(request):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Medicos.objects.filter(especialidade__icontains=search)
        return render(request, "telmedicos.html", data)
    else:
        data['db'] = Especialidades.objects.all()
    return render(request, 'telespecialidades.html', data)

def telmedicos(request, especialidade):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Medicos.objects.filter(especialidades__icontains=search)
        return render(request, "telmedicos.html", data)
    else:
        data['db'] = Medicos.objects.all()
    return render(request, 'telmedicos.html', data)

def teldata(request):
    data = {}
    data['db'] = AgendamentoTeste.objects.all()
    return render(request, "teldata.html", data)

def agendar(request, pk):
    data = {}
    data['dbagendamento'] = AgendamentoTeste.objects.get(pk=pk)
    data['formagendamento'] = AgendamentoForm(instance=data['dbagendamento'])
    data['formdados'] = ConfirmarForm()
    data['teste'] = Medicos.objects.get(pk=pk-10)
    data['formteste'] = MedicosForm(instance=data['teste'])
    return render(request, 'agendar.html', data)

def createconfirmar(request):
    form = ConfirmarForm(request.POST or None)
    if form.is_valid():
        form.save()
        message = client.messages.create(
            to="+5511969644107",
            from_="+19206478784",
            body=f'Sua consulta foi agendada {Confirmar.objects.all()}')
        print(message.sid)
        return redirect('home')

def telagendamentos(request):
    data = {}
    search = request.GET.get('search')
    if search:
        data['db'] = Confirmar.objects.get(cpf__icontains=search)
        return render(request, "viewagendamento.html", data)
    else:
        data['db'] = Confirmar.objects.all()
        return render(request, "telagendamentos.html", data)

def viewagendamento(request, cpf):
    data = {}
    data['db'] = Confirmar.objects.get(cpf=cpf)
    data['dbteste'] = AgendamentoTeste.objects.get(cpf=cpf)
    return render(request, 'viewagendamento.html', data)

def telerro(request):
    return render(request, 'telerro.html')

#def deleteagendamento(request, pk):
#    db = AgendamentoTeste.objects.get(pk=pk)
#    db.delete()
#    return redirect('home')