from django.urls import path
from . import views

urlpatterns = [
    path('cadastromed/', views.cadastromed, name='cadastromed'),
    path('loginmed/', views.loginmed, name='loginmed'),
    path('telmedico/', views.telmedico, name='telmedico'),
]
