from django.db import models
from django.contrib.auth import get_user_model

# chave cimetrica = publica

# Create your models here.

class Cadastro(models.Model):
    username = models.CharField(max_length=100)
    email = models.EmailField(max_length=100, null=False, blank=False)
    senha = models.CharField(max_length=50)

class Cliente(models.Model):
    STATUS = (
        ('SP', 'São Paulo'),
        ('RJ', 'Rio de Janeiro')
    )
    STATUS2 = (
        ('SIM', 'Sim'),
        ('NAO', 'Não')
    )
    nome = models.CharField(max_length=100)
    data_nasc = models.DateField()
    cpf = models.CharField(max_length=14)
    telefone = models.IntegerField()
    email = models.EmailField(max_length=100, null=False, blank=False)
    cidade = models.CharField(
        max_length=2,
        choices=STATUS,
        blank=False,
        null=False
    )
    aqtad = models.CharField(max_length=100)
    tddc = models.CharField(
        max_length=3,
        choices=STATUS2,
        blank=False,
        null=False
    )
    sdi = models.CharField(max_length=100)
    qedsi = models.CharField(max_length=100)
    fam = models.CharField(max_length=100)
    tmc = models.CharField(
        max_length=3,
        choices=STATUS2,
        blank=False,
        null=False)
    adpcm = models.CharField(
        max_length=3,
        choices=STATUS2,
        blank=False,
        null=False)
    umc = models.CharField(
        max_length=3,
        choices=STATUS2,
        blank=False,
        null=False
    )
    pmtccb = models.CharField(
        max_length=3,
        choices=STATUS2,
        blank=False,
        null=False
    )
    palncc = models.CharField(max_length=100)
    especifique = models.TextField()
    utpd = models.CharField(
        max_length=3,
        choices=STATUS2,
        blank=False,
        null=False
    )
    create_at = models.DateTimeField(auto_now_add=True)
    update_at = models.DateTimeField(auto_now=True)
    #def __str__(self):
    #    return self.nome, self.data_nasc, self.cpf, self.telefone, self.cidade, self.aqtad, self.tddc, self.sdi, self.qedsi, self.fam, self.tmc, self.adpcm, self.umc, self.pmtccb, self.palncc, self.especifique, self.utpd


