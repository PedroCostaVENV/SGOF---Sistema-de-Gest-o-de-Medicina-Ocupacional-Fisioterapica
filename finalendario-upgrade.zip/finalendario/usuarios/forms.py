from django.forms import ModelForm
from app.models import Cadastro, Cliente
from .models import AgendamentoTeste, Especialidades, Medicos, Clinica, Confirmar
from django import forms

class ClinicaForm(ModelForm):
    class Meta:
        model = Clinica
        fields = ['nome', 'rua', 'numero', 'cidade', 'cep']

class ConfirmarForm(ModelForm):
    hora = forms.CharField(widget=forms.TextInput(attrs={'placeholder': '00:00...'}))
    data = forms.DateField(
        label=('Data da Consulta:'),
        input_formats=["%d/%m/%Y",],
        widget=forms.DateInput(format='%d/%m/%Y')
    )
    class Meta:
        model = Confirmar
        fields = ['cpf', 'telefone', 'data', 'hora', 'medico']

class EspecialidadesForm(ModelForm):
    class Meta:
        model = Especialidades
        fields = ['especialidades']

class MedicosForm(ModelForm):
    class Meta:
        model = Medicos
        fields = ['nome','crm', 'idade', 'especialidade']

class AgendamentoForm(ModelForm):
    hora = forms.CharField(widget=forms.TextInput(attrs={'placeholder': '00:00...'}))
    data = forms.DateField(
        label=('Data:'),
        input_formats=["%d/%m/%Y",],
        widget=forms.DateInput(format='%d/%m/%Y')
    )
    class Meta:
        model = AgendamentoTeste
        fields = ['data', 'hora']

